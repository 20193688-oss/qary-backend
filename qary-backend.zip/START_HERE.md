# QARY Backend — Render-ready ZIP

This ZIP is pre-configured so the contents unzip **directly at the root**. No nested folders. No "src/src/" confusion.

## What's inside

```
.  ← when extracted, THIS level has:
├─ package.json        ← "main": "src/index.js", "start": "node src/index.js"
├─ src/
│  ├─ index.js         ← Express server entry
│  ├─ routes/          ← auth, payments, profile
│  ├─ webhooks/        ← stripe
│  └─ lib/             ← qr-signer
├─ Dockerfile
├─ README_BACKEND.md   ← full deploy docs (Render/Railway/Cloud Run)
└─ .gitignore
```

## Render settings (copy/paste exactly)

| Field | Value |
|---|---|
| Language | Node |
| Region | Oregon (or Ohio — closer to Peru than EU) |
| Branch | (if using Git) main |
| Root Directory | *(leave empty)* |
| Build Command | `npm install` |
| Pre-Deploy Command | *(leave empty)* |
| Start Command | `npm start` |
| Auto-Deploy | On Commit |
| Instance Type | Free (to test) → Starter $7/mo (for real use) |

## Environment variables (Settings → Environment)

Add these BEFORE first deploy, or the backend will start but fail on first request:

| Key | Value |
|---|---|
| `NODE_ENV` | `production` |
| `JWT_SECRET` | *(64-hex string — see below)* |
| `QR_SIGNING_SECRET` | *(64-hex string — see below)* |
| `CORS_ORIGIN` | `https://your-frontend.vercel.app` (your real URL) |
| `PORT` | *(leave unset — Render sets it automatically)* |

Generate the two secrets on your machine:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Run that command **twice** — once for each secret. Paste each value into Render.

## First request after deploy

Wait until Render shows "Live" status, then:

```bash
curl https://YOUR-SERVICE.onrender.com/health
```

Expected response:

```json
{"ok":true,"service":"qary-backend","version":"1.0.0","sandbox":false,...}
```

If you see `{"ok":true}` → done. Move on to pointing the frontend at this URL.

## Full docs

Read `README_BACKEND.md` for:
- All 6 test curl commands (OTP, payments, webhook, avatar)
- How to add Twilio / SendGrid / Stripe later
- Production hardening checklist

## If something fails

1. Render → **Logs** → read the stack trace
2. Common issues:
   - Missing env var → add it → **Manual Deploy**
   - Port binding error → remove any `PORT` env var you set manually
   - Module not found → check Logs show `npm install` completed successfully

Good luck 🚀
