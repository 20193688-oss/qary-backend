/* Stripe webhook — sandbox compatible
 * ─────────────────────────────────────
 * If STRIPE_WEBHOOK_SECRET is set: verify signature (production path).
 * Otherwise: accept any JSON body and log it (sandbox path — for testing
 * your front/back integration without a Stripe account).
 */

'use strict';

module.exports = function stripeWebhookHandler(req, res) {
  const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;
  const IS_SANDBOX = process.env.NODE_ENV !== 'production';

  let event;
  const rawBody = req.body; // Buffer (mounted with express.raw)

  if (WEBHOOK_SECRET && process.env.STRIPE_SECRET_KEY) {
    try {
      const Stripe = require('stripe');
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      const sig = req.headers['stripe-signature'];
      event = stripe.webhooks.constructEvent(rawBody, sig, WEBHOOK_SECRET);
    } catch (err) {
      console.error('[webhook] signature verification failed:', err.message);
      return res.status(400).json({ error: 'bad_signature' });
    }
  } else if (IS_SANDBOX) {
    // Parse whatever JSON came in
    try {
      event = JSON.parse(rawBody.toString('utf8'));
    } catch (err) {
      return res.status(400).json({ error: 'bad_json' });
    }
    console.log('[webhook SANDBOX] no signature check — any payload accepted');
  } else {
    return res.status(400).json({ error: 'webhook_not_configured' });
  }

  // Handle event
  console.log(`[webhook] received event: ${event.type || 'unknown'}`);
  switch (event.type) {
    case 'payment_intent.succeeded':
      console.log(`  ✅ tx paid: ${event.data?.object?.id} amount=${event.data?.object?.amount}`);
      // TODO: update DB, emit socket event
      break;
    case 'payment_intent.payment_failed':
      console.log(`  ❌ tx failed: ${event.data?.object?.id}`);
      break;
    case 'charge.refunded':
      console.log(`  ↩️  refund: ${event.data?.object?.id}`);
      break;
    default:
      console.log(`  ℹ️  (unhandled type)`);
  }

  res.json({ received: true, type: event.type });
};
