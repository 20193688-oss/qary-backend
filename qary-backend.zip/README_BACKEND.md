# QARY backend — deploy guide

Minimal Express server for OTP, payments, webhooks, and avatar upload. Runs in **sandbox mode by default** (no external API keys required).

## Run locally

```bash
cd backend
cp ../.env.example .env
# edit .env — at minimum set JWT_SECRET and QR_SIGNING_SECRET
npm install
npm start
```

Output:

```
╔════════════════════════════════════════════╗
║  QARY backend listening on port 3000       ║
║  Mode: SANDBOX (OTPs visible in logs)      ║
║  Health: http://localhost:3000/health      ║
╚════════════════════════════════════════════╝
```

## Generate secrets

```bash
# One-liner for each secret
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Paste the output into `JWT_SECRET` and `QR_SIGNING_SECRET` in `.env`.

## Sandbox behavior

When `NODE_ENV` ≠ `production` (default), the backend:
- Logs OTP codes to the console AND includes them in the response as `sandbox_otp`
- Accepts webhook events without signature verification if `STRIPE_WEBHOOK_SECRET` is missing
- Creates a local mock payment URL (`/api/payments/mock-checkout`) when Stripe is not configured

Set `NODE_ENV=production` on your host to disable all three.

## 6 curl commands to smoke-test

Export the base URL once (local or deployed):

```bash
export API=http://localhost:3000        # or https://qary-backend.onrender.com
```

### 1. Health check
```bash
curl $API/health
```

### 2. Send OTP
```bash
curl -X POST $API/api/auth/send-otp \
  -H 'Content-Type: application/json' \
  -d '{"email":"test@qary.pe","phone":"+51987654321","purpose":"login"}'
# → { "request_id":"otp_...", "sandbox_otp":"483921", ... }
```

### 3. Verify OTP
```bash
curl -X POST $API/api/auth/verify-otp \
  -H 'Content-Type: application/json' \
  -d '{"request_id":"otp_...","otp":"483921"}'
# → { "access_token":"eyJ...", "refresh_token":"eyJ...", "user":{...} }
```

### 4. Create payment intent (sandbox — no Stripe key needed)
```bash
curl -X POST $API/api/payments/create-intent \
  -H 'Content-Type: application/json' \
  -d '{"amount":2850,"currency":"PEN","description":"Qary Moto · San Isidro"}'
# → { "tx_id":"tx_...", "qr_payload":"v1....", "payment_url":"..../mock-checkout?tx=..." }
```

### 5. Simulate webhook
```bash
curl -X POST $API/api/payments/webhook \
  -H 'Content-Type: application/json' \
  -d '{"type":"payment_intent.succeeded","data":{"object":{"id":"pi_test_123","amount":2850}}}'
# → { "received":true, "type":"payment_intent.succeeded" }
```

### 6. Upload avatar
```bash
# Create a small test image first if needed:
#   convert -size 128x128 xc:#2B2FD9 /tmp/avatar.png
curl -X POST $API/api/profile/avatar \
  -F 'file=@/tmp/avatar.png'
# → { "avatar_url":"http://localhost:3000/uploads/avatar_...", ... }
```

## Deploy — Render (recommended for simplicity)

1. Push this repo to GitHub.
2. Go to https://render.com → **New → Web Service**.
3. Connect your repo. Fill:
   - **Root Directory:** `backend`
   - **Environment:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. Add environment variables (at minimum: `JWT_SECRET`, `QR_SIGNING_SECRET`, `NODE_ENV=production`, `CORS_ORIGIN=https://your-frontend.vercel.app`).
5. Deploy. Render gives you a URL like `https://qary-backend.onrender.com`.
6. Paste that URL into `frontend/dist/config.js` and redeploy the frontend.

> **Note:** Render's free tier **sleeps after 15 min of inactivity** — first request after idle takes ~30 s. For staging that's fine; for production use the $7/mo starter.

## Deploy — Railway

```bash
# Using the Railway CLI
npm install -g @railway/cli
railway login
cd backend
railway init
railway up
```

In the Railway dashboard, add the same env vars as Render. Railway gives you a public URL under **Settings → Networking**.

## Deploy — Google Cloud Run

```bash
# From /backend
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

# Enable services (once)
gcloud services enable run.googleapis.com artifactregistry.googleapis.com

# Build the image
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/qary-backend

# Deploy
gcloud run deploy qary-backend \
  --image gcr.io/YOUR_PROJECT_ID/qary-backend \
  --region us-central1 \
  --platform managed \
  --allow-unauthenticated \
  --set-env-vars "NODE_ENV=production,JWT_SECRET=...,QR_SIGNING_SECRET=...,CORS_ORIGIN=https://your-frontend.vercel.app"
```

Cloud Run scales to zero (no cost when idle) and returns a URL like `https://qary-backend-xxxx-uc.a.run.app`.

## Deploy — Fly.io

```bash
cd backend
fly launch                  # answers: app name qary-backend, region lim (Lima closest)
fly secrets set JWT_SECRET=... QR_SIGNING_SECRET=... NODE_ENV=production
fly deploy
```

## Docker (any host)

```bash
cd backend
docker build -t qary-backend .
docker run -p 3000:3000 --env-file .env qary-backend
```

Image is based on `node:20-alpine`, runs as non-root user `qary`, includes a `HEALTHCHECK` against `/health`.

## Security checklist before going to production

- [ ] `NODE_ENV=production` on the host (disables sandbox OTP leak, webhook bypass)
- [ ] `JWT_SECRET` and `QR_SIGNING_SECRET` are 64-hex-char random values, stored in host secrets manager (NOT in git)
- [ ] `CORS_ORIGIN` set to your exact frontend URL(s), not `*`
- [ ] `STRIPE_WEBHOOK_SECRET` set before enabling Stripe
- [ ] `uploads/` directory is ephemeral on serverless hosts (Render free, Cloud Run) — move to S3/R2 for persistence
- [ ] In-memory OTP store + tx ledger only work with **one instance**. Scale to multiple replicas → switch to Redis (see README_DEPLOY.md §Scaling)
- [ ] Rate limiting is in-memory too — same Redis recommendation

## Files you should NOT commit / upload

- `.env` (real values)
- `node_modules/` (rebuilt on host)
- `uploads/` (user-uploaded avatars)
- Any file with real `sk_live_`, Twilio auth token, or SendGrid API key

The included `.gitignore` covers these.
